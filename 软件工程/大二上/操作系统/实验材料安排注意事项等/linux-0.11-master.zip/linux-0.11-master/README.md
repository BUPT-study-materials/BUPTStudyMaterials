## Linux-0.11 ##
### RTFSC ###
Linus曾经说过：RTFSC - Read The Fucking Source Code.

本代码是目前能够找到的最早的Linux的内核版本。（如果你能找到更早版本的Linux源码，请一定要告诉[我](karottc@gmail.com)。;-) ）

本代码中的注释99%都来源于赵炯老师的那本[Linux-0.11源码完全注释](http://book.douban.com/subject/1231236/)，这么算的话，我好像只是一个搬运工....（不过搬运的过程经过了自己的手，总能得到一些东西... :-) ）

##### 附注 #####
目前更新到kernel部分的注释，驱动部分应该不会更新，目前感兴趣的部分在kernle、内存管理、网络(这个版本还没有网络....). 就酱 ! ! !